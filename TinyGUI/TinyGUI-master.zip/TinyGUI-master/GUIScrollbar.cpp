#include "GUIScrollbar.h"

GUIScrollbar::GUIScrollbar(GUIInterface* parent) :GUIElement(parent, GUIType::SCROLLBAR, GUILayerType::CONTROL)
{

}

void GUIScrollbar::OnNeutral()
{

}

void GUIScrollbar::OnHover()
{

}

void GUIScrollbar::OnClick(const sf::Vector2f& mousepos)
{

}

void GUIScrollbar::OnLeave()
{

}

void GUIScrollbar::OnRelease()
{

}


void GUIScrollbar::Update(const float& dT)
{

}

void GUIScrollbar::ReadIn(KeyProcessing::Keys& keys)
{

}


