#include "Block.h"
#include "Globals.h"

Block::Block(const sf::Vector2f& init_pos)
{
	this->setPosition(init_pos);
	this->setFillColor(sf::Color::Transparent);
	this->setOutlineColor(sf::Color::White);
	this->setOutlineThickness(1);
	this->setSize(sf::Vector2f{ DIMENSION, DIMENSION });
}
void Block::ToggleWall(const bool& state)
{
	(state) ? traversable = true : traversable = false;
	(traversable) ? this->setFillColor(sf::Color::Transparent) : this->setFillColor(sf::Color::Magenta);
}