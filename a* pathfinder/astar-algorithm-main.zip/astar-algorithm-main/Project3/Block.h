#ifndef BLOCK_H
#define BLOCK_H
#include <SFML/Graphics.hpp>
#include <random>
struct Block : public sf::RectangleShape
{
	float g = 0;
	float f = 0;
	float h = 0;
	bool traversable = true;
	unsigned int parent_node_index = 0;
	Block(const sf::Vector2f& init_pos);
	void ToggleWall(const bool& state);
};


#endif