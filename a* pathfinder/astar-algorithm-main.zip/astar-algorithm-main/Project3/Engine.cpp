#include "Engine.h"
#include "Globals.h"
#include <algorithm>
#include <iostream>

Engine::Engine(sf::RenderWindow* winPtr, sf::Vector2f* mousePtr)
	:m_winPtr(winPtr), m_mousePtr(mousePtr)
{
	for (float y = 0; y < HEIGHT; y += DIMENSION)
	{
		for (float x = 0; x < WIDTH; x += DIMENSION)
		{
			m_blockStorage.emplace_back(sf::Vector2f{ x,y });
		}
	}
}
void Engine::Start()
{
	if (m_markerStorage[0] != -1 && m_markerStorage[1] != -1)
	{
		m_openList.push_back(m_markerStorage[0]);
		while (!m_openList.empty())
		{
			m_winPtr->clear();
			Display();
			m_winPtr->display();
			int lowestOpenListIndexF = FetchLowestFIndex();
			unsigned int index = m_openList[lowestOpenListIndexF];
			Block& currentBlock = m_blockStorage[index];
			currentBlock.setFillColor(sf::Color::Yellow);
			auto it = m_openList.begin() + lowestOpenListIndexF;
			m_openList.erase(it);
			m_closedList.push_back(index);
			if (&currentBlock == &m_blockStorage[m_markerStorage[1]])
			{
				//RetracePath();
				return;
			}
			std::vector<unsigned int> neighbors = GetBlockNeighbors(currentBlock);
			for (const unsigned int& i : neighbors)
			{
				Block& neighbor = m_blockStorage[i];
				auto it = std::find_if(m_closedList.begin(), m_closedList.end(), [i](int x) {return x == i; });
				if (!neighbor.traversable || (it != m_closedList.end()))
				{
					continue;
				}
				auto open = std::find_if(m_openList.begin(), m_openList.end(), [i](int x) {return x == i; });
				float MovementCostToNeighbor = currentBlock.g + CalculateH(neighbor);
				if (MovementCostToNeighbor < neighbor.g || (open == m_openList.end()))
				{
					neighbor.g = MovementCostToNeighbor;
					neighbor.h = CalculateH(neighbor);
					neighbor.f = neighbor.g + neighbor.h;
					neighbor.parent_node_index = index;

					if (std::find_if(m_openList.begin(), m_openList.end(), [i](int x) {return x == i; }) == m_openList.end())
					{
						m_openList.push_back(i);
					}
				}
			}

		}
	}
	
}
void Engine::SetMarkers()
{
	unsigned int n = FetchMouseIndex();
	if (m_markerCount == 0)
	{
		m_blockStorage[n].setFillColor(sf::Color::Red);
		m_markerCount++;
		m_markerStorage[0] = n;
	}
	else if (m_markerCount == 1)
	{
		m_blockStorage[n].setFillColor(sf::Color::Blue);
		m_markerCount++;
		m_markerStorage[1] = n;
	}
}
void Engine::MoveMarker(DIRECTION direction, MARKER marker)
{
	Block& currentBlock = m_blockStorage[m_markerStorage[marker]];
	sf::Vector2f futurePos = currentBlock.getPosition() + DIRECTIONS[direction];
	if (futurePos.x < 0) return;
	if (futurePos.x >= WIDTH) return;
	if (futurePos.y < 0) return;
	if (futurePos.y >= HEIGHT) return;
	unsigned int futurePos_index = CartesianToNth(futurePos);
	Block& futureBlock = m_blockStorage[futurePos_index];
	if (!futureBlock.traversable)
	{
		return;
	}
	m_markerStorage[marker] = CartesianToNth(futurePos);
	currentBlock.setFillColor(sf::Color::Transparent);
	(marker == MARKER::START) ? futureBlock.setFillColor(sf::Color::Red) : futureBlock.setFillColor(sf::Color::Blue);
	Reset();
	Start();

}
void Engine::RetracePath()
{
	unsigned int currentNode_index = m_blockStorage[m_markerStorage[1]].parent_node_index;
	while (currentNode_index != m_markerStorage[0])
	{
		Block& currentNode = m_blockStorage[currentNode_index];
		currentNode.setFillColor(sf::Color::Yellow);
		m_path.push_back(&currentNode);
		currentNode_index = currentNode.parent_node_index;
	}
}
void Engine::PopulateCell(const bool& mouseClick)
{
	unsigned int index = 0;
	if (mouseClick)
	{
		index = FetchMouseIndex();
		m_blockStorage[index].ToggleWall(false);
		m_wallStorage.push_back(index);
	}
	else
	{
		for (int i = 0; i < 100; i++)
		{
			index = m_uniform(m_randomGenerator);
			m_blockStorage[index].ToggleWall(false);
			m_wallStorage.push_back(index);
		}
	}
}
void Engine::Display()
{
	for (const Block& b : m_blockStorage)
	{
		m_winPtr->draw(b);
	}
}
void Engine::Reset()
{
	m_openList.clear();
	m_closedList.clear();
	for (Block* b : m_path)
	{
		b->setFillColor(sf::Color::Transparent);
		b->traversable = true;
	}
	m_path.clear();
}
float Engine::CalculateH(const Block& currentBlock) const
{
	sf::Vector2f end = m_blockStorage[m_markerStorage[1]].getPosition();
	sf::Vector2f start = currentBlock.getPosition();
	float dx = abs(end.x - start.x);
	float dy = abs(end.y - start.y);
	if (dy < dx)
	{
		return float(DIAGONAL_DIMENSION*dy + (dx - dy)*DIMENSION);
	}
	return float(DIAGONAL_DIMENSION*dx + (dy - dx)*DIMENSION);
}
unsigned int Engine::FetchLowestFIndex()
{
	std::vector<Block>& blockStorage = m_blockStorage;
	auto it = std::min_element(m_openList.begin(), m_openList.end(), [&blockStorage](const unsigned int& index1, const unsigned int& index2)
		{
			return blockStorage[index1].f < blockStorage[index2].f;
		}
	);
	unsigned int openListIndex = it - m_openList.begin();
	return openListIndex;
}
inline unsigned int Engine::FetchMouseIndex()
{
	return CartesianToNth(*m_mousePtr);
}
std::vector<unsigned int> Engine::GetBlockNeighbors(const Block& currentBlock) 
{
	std::vector<unsigned int> j;
	for (int i = 0; i < 4; i++)
	{
		sf::Vector2f currentPosition = currentBlock.getPosition();
		currentPosition += DIRECTIONS[i];
		if (currentPosition.x < 0) continue;
		if (currentPosition.x >= WIDTH) continue;
		if (currentPosition.y < 0) continue;
		if (currentPosition.y >= HEIGHT) continue;
		unsigned int n = CartesianToNth(currentPosition);
		j.push_back(n);
	}
	return j;
}


unsigned int Engine::CartesianToNth(sf::Vector2f vec)
{
	vec.x = std::floor(vec.x / DIMENSION);
	vec.y = std::floor(vec.y / DIMENSION);
	return (vec.y * NCOLS + vec.x);
}
std::mt19937 randomGenerator;
std::normal_distribution<float> init(WIDTH / 2, 100);
std::uniform_int_distribution<int> uniform(0, (NCOLS * HEIGHT/DIMENSION) - 1);

std::mt19937 Engine::m_randomGenerator = randomGenerator;
std::normal_distribution<float> Engine::m_gaussian = init;
std::uniform_int_distribution<int> Engine::m_uniform = uniform;