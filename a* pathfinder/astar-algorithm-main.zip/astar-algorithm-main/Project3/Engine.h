#ifndef ENGINE_H
#define ENGINE_H
#include "Block.h"
#include "Globals.h"
#include <vector>
#include <deque>
class Engine
{
private:
	sf::RenderWindow* m_winPtr;
	sf::Vector2f* m_mousePtr;
	std::vector<Block> m_blockStorage;
	std::vector<Block*> m_path;

	static std::mt19937 m_randomGenerator;
	static std::uniform_int_distribution<int> m_uniform;
	static std::normal_distribution<float> m_gaussian;

	unsigned int m_markerStorage[2];
	unsigned int m_markerCount = 0;

	std::vector<unsigned int> m_wallStorage;
	std::deque<unsigned int> m_openList;
	std::vector<unsigned int> m_closedList;
	
	static unsigned int CartesianToNth(sf::Vector2f cartesian);
	std::vector<unsigned int> GetBlockNeighbors(const Block& currentBlock);
	unsigned int FetchLowestFIndex();
	float CalculateH(const Block& currentBlock) const;
	void RetracePath();
	void ForwardRetracePath();

public:
	
	enum DIRECTION
	{
		NORTH = 0, EAST, SOUTH, WEST
	};
	enum MARKER
	{
		START = 0, END
	};

	Engine(sf::RenderWindow* winPtr, sf::Vector2f* mousePtr);
	void Start();
	void Display();
	void MoveMarker(DIRECTION direction, MARKER marker);
	void SetMarkers();
	
	inline unsigned int FetchMouseIndex();
	void Reset();
	void PopulateCell(const bool& mouseclick);
	
};
#endif