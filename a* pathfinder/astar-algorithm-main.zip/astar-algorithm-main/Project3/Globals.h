#ifndef GLOBALS_H
#define GLOBALS_H
#include <SFML/Graphics.hpp>
#include <vector>
#include "Block.h"
#define WIDTH 800
#define HEIGHT 800
#define DIMENSION 20
#define NCOLS WIDTH / DIMENSION
#define DIAGONAL_DIMENSION sqrt(pow(DIMENSION, 2) + pow(DIMENSION,2))
extern sf::Vector2f DIRECTIONS[4];

#endif // !GLOBALS_H
