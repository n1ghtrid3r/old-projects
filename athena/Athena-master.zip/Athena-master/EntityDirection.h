#ifndef ENTITY_DIRECTION_H
#define ENTITY_DIRECTION_H
enum class Direction {
	UP, DOWN, LEFT, RIGHT
};

#endif