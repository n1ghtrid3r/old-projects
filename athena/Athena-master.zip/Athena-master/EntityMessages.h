#ifndef ENTITYMESSAGES_H
#define ENTITYMESSAGES_H
enum class SystemMessage {
	CHANGE_STATE
};

#endif