#ifndef ENTITYSTATES_H
#define ENTITYSTATES_H
enum class EntityState {
	WALKING, IDLE, ATTACK, DEAD
};


#endif