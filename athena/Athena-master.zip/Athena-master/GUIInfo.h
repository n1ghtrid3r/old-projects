#ifndef GUIINFO_H
#define GUIINFO_H

enum class GUIState {
	NEUTRAL, FOCUSED, CLICKED
};
enum class GUIType {
	LABEL, TEXTFIELD, SCROLLBAR, WINDOW, NULLTYPE
};


#endif