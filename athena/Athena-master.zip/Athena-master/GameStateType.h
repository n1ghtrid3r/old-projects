#ifndef STATETYPE_H
#define STATETYPE_H
enum class StateType {
	INTRO, MAINMENU, OPTIONS, GAME, GAMELOST, NULLSTATE
};


#endif