#ifndef ORIGIN_H
#define ORIGIN_H

enum class OriginX {
	LEFT, MIDDLE, RIGHT
};
enum class OriginY {
	TOP, MIDDLE, BOT
};

#endif