#ifndef SYSTEM_COLLIDABLE_H
#define SYSTEM_COLLIDABLE_H

class System_Collidable
{
protected:
public:
};


#endif