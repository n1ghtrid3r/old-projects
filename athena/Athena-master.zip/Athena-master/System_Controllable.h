#ifndef SYSTEM_CONTROLLABLE_H
#define SYSTEM_CONTROLLABLE_H

class System_Controllable
{
protected:
public:

};


#endif
