#ifndef SYSTEM_RENDERER_H
#define SYSTEM_RENDERER_H
class System_Renderer
{
protected:
public:

};



#endif