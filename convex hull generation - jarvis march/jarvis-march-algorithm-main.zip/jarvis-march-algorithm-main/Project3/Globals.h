#ifndef GLOBALS_H
#define GLOBALS_H
#define WIDTH 500
#define HEIGHT 500
#define TOTAL_POINTS 1000


#endif