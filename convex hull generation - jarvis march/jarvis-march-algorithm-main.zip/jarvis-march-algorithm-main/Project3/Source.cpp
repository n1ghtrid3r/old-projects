#include <SFML/Graphics.hpp>
#include <algorithm>
#include <iostream>
#include "Globals.h"
#include "Utility.h"
#include <set>


void start(const std::vector<sf::Vertex*>& points, sf::RenderWindow* winptr)
{
	sf::VertexArray AtoB{ sf::PrimitiveType::LineStrip };
	sf::VertexArray BtoC{ sf::PrimitiveType::LineStrip };
	//we need to create an openlist with all the points but the convex hull.
	std::vector<sf::Vertex*> convexhull;
	std::vector<sf::Vertex*> openlist = points;
	auto leftmostvertex = std::min_element(points.begin(), points.end(), [](sf::Vertex* v1, sf::Vertex* v2)
	{
		return v1->position.x < v2->position.x;
	});	
	sf::Vertex* A = *leftmostvertex;
	convexhull.push_back(A);
	sf::Vertex* B;
	sf::Vertex* C;
	while (true)
	{
		std::vector<sf::Vertex*> closedlist = convexhull;
		sf::Vertex* B = UTIL::randomVertex(openlist, closedlist);
		if (B == nullptr) break;
		closedlist.push_back(B);
		while(true)
		{
			AtoB.clear();
			BtoC.clear();
			sf::Vertex* C = UTIL::randomVertex(openlist, closedlist);
			if (C == nullptr)
			{
				convexhull.push_back(B);
				A = B;
				break;
			}
			AtoB.append(*A);
			AtoB.append(*B);
			BtoC.append(*B);
			BtoC.append(*C);
			winptr->clear();
			winptr->draw(UTIL::constructpoints(convexhull, sf::PrimitiveType::LineStrip));
			winptr->draw(UTIL::constructpoints(points, sf::PrimitiveType::Points));
			winptr->draw(AtoB);
			winptr->draw(BtoC);
			winptr->display();
			UTIL::DIRECTION ABCorientation = UTIL::orientation(A->position, B->position, C->position);
			if (ABCorientation == UTIL::DIRECTION::CLOCKWISE)
			{
				closedlist.push_back(C);
				continue;
			}
			else if (ABCorientation == UTIL::DIRECTION::ANTICLOCKWISE)
			{
				closedlist.push_back(B);
				B = C;
				continue;
			}
		}
	}


}



int main()
{
	sf::RenderWindow myWindow(sf::VideoMode(WIDTH, HEIGHT), "Jarvis March", sf::Style::Default);
	sf::VertexArray drawables;
	std::vector<sf::Vertex*> pointers;
	for (int i = 0; i < TOTAL_POINTS; i++)
	{
		drawables.append(sf::Vertex{ UTIL::randomposition() });
	}
	for (int i = 0; i < drawables.getVertexCount(); i++)
	{
		sf::Vertex* p = &drawables[i];
		pointers.push_back(p);
	}

	
	start(pointers, &myWindow);
	


	while (myWindow.isOpen())
	{
		sf::Event evnt;

		while (myWindow.pollEvent(evnt))
		{
			switch (evnt.type)
			{
				case sf::Event::EventType::Closed:
				{
					myWindow.close();
				}
			}
		}
		myWindow.clear();
		myWindow.draw(drawables);
		myWindow.display();
	}
}