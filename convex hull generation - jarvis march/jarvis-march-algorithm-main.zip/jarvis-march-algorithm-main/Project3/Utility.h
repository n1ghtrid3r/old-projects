#ifndef UTILITY_H
#define UTILITY_H
#include <SFML/Graphics.hpp>
#include <random>
#include <chrono>
#include "Globals.h"


namespace UTIL
{
	enum class DIRECTION
	{
		CLOCKWISE = 0, ANTICLOCKWISE
	};
	
	unsigned int seed = std::chrono::steady_clock().now().time_since_epoch().count();
	std::mt19937 randomgenerator{ seed };
	std::normal_distribution<float> gaussianx(WIDTH/2, 75);
	std::normal_distribution<float> gaussiany(HEIGHT / 2, 75);
	

	DIRECTION orientation(const sf::Vector2f& p1, const sf::Vector2f& p2, const sf::Vector2f& p3)
	{
		sf::Vector3f P1toP2{ p2.x - p1.x, p2.y - p1.y, 0 };
		sf::Vector3f P2toP3{ p3.x - p2.x, p3.y - p2.y, 0 };
		return (((P1toP2.y * P2toP3.x) - (P1toP2.x * P2toP3.y)) > 0) ? UTIL::DIRECTION::ANTICLOCKWISE : UTIL::DIRECTION::CLOCKWISE;
	}
	unsigned int leftmostpoint(const sf::VertexArray& points)
	{
		float minimumdistance = WIDTH;
		unsigned int minimumindex = 0;
		for (int i = 0; i < points.getVertexCount(); i++)
		{
			const sf::Vertex& v = points[i];
			if (v.position.x < minimumdistance)
			{
				minimumdistance = v.position.x;
				minimumindex = i;
			}
		}
		return minimumindex;
	}
	sf::Vector2f randomposition()
	{
		return sf::Vector2f{ UTIL::gaussianx(randomgenerator), UTIL::gaussiany(randomgenerator) };
	}
	unsigned int randomindex(unsigned int lowerbound, unsigned int upperbound)
	{
		std::uniform_int_distribution<int> ri(lowerbound, upperbound);
		return ri(randomgenerator);
	}
	sf::Vertex* randomVertex(std::vector<sf::Vertex*> openlist, std::vector<sf::Vertex*> closedlist)
	{
		if (openlist.size() == closedlist.size()) return nullptr;
		unsigned int ri = randomindex(0, openlist.size() - 1);
		sf::Vertex* rv = openlist[ri];
		if (std::find(closedlist.begin(), closedlist.end(), rv) == closedlist.end()) return rv;
		return randomVertex(openlist, closedlist);
		
	}
	sf::VertexArray constructpoints(const std::vector<sf::Vertex*> arr, sf::PrimitiveType type)
	{
		sf::VertexArray points{ type };
		for (sf::Vertex* v : arr)
		{
			if (v != nullptr)
			{
				points.append(v->position);
			}
		}
		return points;
	}
}

#endif