#include "Engine.h"
#include <iostream>
float RandomFloat(float a, float b) {
	float random = ((float)rand()) / (float)RAND_MAX;
	float diff = b - a;
	float r = random * diff;
	return a + r;
}
Engine::Engine(sf::RenderWindow* winPtr, sf::Vector2f* mousePos)
	:m_winPtr(winPtr), m_mousePos(mousePos)
{
	CreateGridBlocks();
	PopulateGrid();
	
}
void Engine::Start()
{
	std::vector<Gridblock> gb = gridBlockStorage;
	for (Gridblock& cell : gb)
	{
		int n = GetGridBlockNeighbors(cell);
		if (cell.m_state)
		{
			if (n < 2)
			{
				cell.toggleState(false);
			}
			if (n == 2 || n == 3)
			{
				cell.toggleState(true);
			}
			if (n > 3)
			{
				cell.toggleState(false);
			}
		}
		else
		{
			if (n < 3)
			{
				cell.toggleState(false);
			}
			if (n == 3)
			{
				cell.toggleState(true);
			}
		}
		
	}
	gridBlockStorage = gb;
}
void Engine::CreateGridBlocks()
{
	for (int y = 0; y < HEIGHT; y += DIMENSION)
	{
		for (int x = 0; x < WIDTH; x += DIMENSION)
		{
			Gridblock block(sf::Vector2f{ float(x), float(y) });
			gridBlockStorage.push_back(block);
		}
	}
}
void Engine::Update()
{
	Start();
}
void Engine::Reset()
{
	for (Gridblock& g : gridBlockStorage)
	{
		g.toggleState(false);
	}
}
void Engine::PopulateMouse()
{
	
	sf::Vector2f gridLoc = CartesianToGrid(*m_mousePos);
	int nthPos = std::floor((gridLoc.y * NCOL) + gridLoc.x);
	Gridblock& g = gridBlockStorage.at(nthPos);
	if (!g.m_state)
	{
		g.toggleState(true);
	}
}
void Engine::PopulateGrid()
{
	for (int i = 0; i < 10000; i++)
	{
		sf::Vector2f gridLoc = { RandomFloat(0,WIDTH), RandomFloat(0,HEIGHT) };
		gridLoc = CartesianToGrid(gridLoc);
		int nthPos = std::floor((gridLoc.y * NCOL) + gridLoc.x);
		Gridblock& g = gridBlockStorage.at(nthPos);
		if (!g.m_state)
		{
			g.toggleState(true);
		}
	}
	
}
void Engine::DrawGridBlocks()
{
	for (const Gridblock &g : gridBlockStorage)
	{
		m_winPtr->draw(g.m_block);
	}
}
sf::Vector2f Engine::CartesianToGrid(const sf::Vector2f& Cartesian)
{
	sf::Vector2f Grid;
	Grid.x = std::floor(Cartesian.x / DIMENSION);
	Grid.y = std::floor(Cartesian.y / DIMENSION);
	return Grid;
}
int Engine::GridToNth(const sf::Vector2f& gridLoc)
{
	int nthPos = std::floor((gridLoc.y * NCOL) + gridLoc.x);
	return nthPos;
}
int Engine::GetGridBlockNeighbors(const Gridblock& currentGridblock)
{
	int counter = 0;
	for (int i = 0; i < 8; i++)
	{
		sf::Vector2f currentPosition = currentGridblock.m_gridrel;
		currentPosition += DIRECTIONS[i];
		if (currentPosition.x < 0) continue;
		if (currentPosition.x >= NCOL) continue;
		if (currentPosition.y < 0) continue;
		if (currentPosition.y >= NCOL) continue;
		int n = GridToNth(currentPosition);
		if (gridBlockStorage[n].m_state)
		{
			counter++;
		}
	}

	return counter;
}