#ifndef ENGINE_H
#define ENGINE_H
#include "Gridblock.h"
#include "Globals.h"
class Engine
{
private:
	sf::RenderWindow* m_winPtr = nullptr;
	sf::Vector2f * m_mousePos = nullptr;
	std::vector<Gridblock> gridBlockStorage;
	std::vector<Gridblock*> aliveCells;
	std::vector<int> toggledIndex;
	sf::Vector2f DIRECTIONS[8] = 
	{
		sf::Vector2f{0,1},
		sf::Vector2f{1,1},
		sf::Vector2f{1,0},
		sf::Vector2f{1,-1},
		sf::Vector2f{0,-1},
		sf::Vector2f{-1,-1},
		sf::Vector2f{-1,0},
		sf::Vector2f{-1,1}
	};

	bool running = false;
	sf::Vector2f CartesianToGrid(const sf::Vector2f& Cartesian);
	int GetGridBlockNeighbors(const Gridblock& currentGridblock);
	int GridToNth(const sf::Vector2f& Grid);
	void Start();
	void CreateGridBlocks();
public:
	Engine(sf::RenderWindow* winPtr, sf::Vector2f* mousePos);
	void PopulateGrid();
	void DrawGridBlocks();
	void Update();
	void Reset();
	void PopulateMouse();
	
};

#endif