#ifndef GLOBALS_H
#define GLOBALS_H
#define WIDTH 1000
#define HEIGHT 1000
#define DIMENSION 10
#define NCOL HEIGHT / DIMENSION

#endif