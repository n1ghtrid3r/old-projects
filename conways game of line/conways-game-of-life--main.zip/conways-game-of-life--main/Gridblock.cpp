#include "Gridblock.h"
#include <iostream>
#include "Globals.h"

Gridblock::Gridblock(const sf::Vector2f& position)
{
	m_block.setFillColor(sf::Color::Transparent); m_block.setOutlineThickness(0.5); m_block.setOutlineColor(sf::Color::White);

	m_block.setSize(sf::Vector2f{ DIMENSION, DIMENSION });
	m_block.setPosition(position);

	m_state = false;

	m_gridrel.x = position.x / DIMENSION;
	m_gridrel.y = position.y / DIMENSION;
	nthGridBlock = (m_gridrel.y * NCOL) + m_gridrel.x;
}

void Gridblock::toggleState(bool state)
{
	m_state = state;
	(m_state) ? m_block.setFillColor(sf::Color::Yellow) : m_block.setFillColor(sf::Color::Transparent);
}