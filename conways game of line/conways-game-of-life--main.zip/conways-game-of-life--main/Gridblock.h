#ifndef GRID_H
#define GRID_H
#include <SFML/Graphics.hpp>
struct Gridblock
{
	bool m_state = false;
	sf::RectangleShape m_block;
	sf::Vector2f m_gridrel;
	int nthGridBlock;
	Gridblock(const sf::Vector2f& position);
	void toggleState(bool state);
	
};

#endif
