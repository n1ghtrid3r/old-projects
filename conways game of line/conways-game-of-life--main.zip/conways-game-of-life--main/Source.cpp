#include <iostream>
#include <SFML/Graphics.hpp>
#include "Engine.h"
#include <random>

int x()
{
	return 3;
}

int main()
{
	sf::RenderWindow myWindow(sf::VideoMode(WIDTH, HEIGHT), "Conway's Game of Life", sf::Style::Default);
	sf::Vector2f mousePos = {};
	Engine engine(&myWindow, &mousePos);
	myWindow.setFramerateLimit(10);
	const int y = x();
	bool start = false;
	while (myWindow.isOpen())
	{
		sf::Event evnt;
		while(myWindow.pollEvent(evnt))
		{
			switch (evnt.type)
			{
				case sf::Event::EventType::Closed:
				{
					myWindow.close();
				}
				case sf::Event::EventType::KeyPressed:
				{
					if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Space))
					{
						
						start = true;
					}
					if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::C))
					{
						start = false;
						engine.Reset();
					}
				}
				case::sf::Event::EventType::MouseButtonPressed:
				{
					if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
					{
						float x = float(sf::Mouse::getPosition(myWindow).x);
						float y = float(sf::Mouse::getPosition(myWindow).y);
						if (x < 0) x = 0; if (y < 0) y = 0;
						if (x > WIDTH) x = WIDTH; if (y > HEIGHT) y = HEIGHT;
						mousePos = sf::Vector2f{ x,y };
						engine.PopulateMouse();
					}
					
				}
			}
		}
		
		myWindow.clear();
		if (start) engine.Update();
		engine.DrawGridBlocks();
		myWindow.display();
	}
}